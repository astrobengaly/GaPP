__all__ = ["cov", "squex", "dsquex", "mat32", "mat52", "mat72", "mat92", 
           "cauchy", "ratquad", "doublecov", "mdsquex", "mddsquex", "mdmat32", 
           "mdmat52", "mdmat72", "mdmat92", "mdcauchy"]
